import NewPlantForm from "./NewPlantForm";
import PlantList from "./PlantList";
import Search from "./Search";

export default function PlantPage({
  plants,
  addPlant,
  markSoldOut,
  updatePlantPrice,
  deletePlant,
  searchTerm,
  setSearchTerm,
}) {
  return (
    <main>
      <NewPlantForm addPlant={addPlant} />
      <Search searchTerm={searchTerm} setSearchTerm={setSearchTerm} />
      <PlantList
        plants={plants}
        markSoldOut={markSoldOut}
        updatePlantPrice={updatePlantPrice}
        deletePlant={deletePlant}
      />
    </main>
  );
}