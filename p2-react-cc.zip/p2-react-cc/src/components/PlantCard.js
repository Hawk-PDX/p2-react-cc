import React, { useState } from "react";

export default function PlantCard({ plant, markSoldOut, updatePlantPrice, deletePlant }) {
  const [isEditing, setIsEditing] = useState(false);
  const [newPrice, setNewPrice] = useState(plant.price);

  const handlePriceUpdate = () => {
    updatePlantPrice(plant.id, newPrice);
    setIsEditing(false);
  };

  return (
    <li className="card" data-testid="plant-item">
      <img src={plant.image} alt={plant.name} />
      <h4>{plant.name}</h4>
      <p>Price: ${plant.price.toFixed(2)}</p>
      {isEditing ? (
        <div>
          <input
            type="number"
            value={newPrice}
            onChange={(e) => setNewPrice(e.target.value)}
          />
          <button onClick={handlePriceUpdate}>Update Price</button>
          <button onClick={() => setIsEditing(false)}>Cancel</button>
        </div>
      ) : (
        <div>
          <button className="primary" onClick={() => markSoldOut(plant.id)}>
            {plant.soldOut ? "Out of Stock" : "In Stock"}
          </button>
          <button onClick={() => setIsEditing(true)}>Edit Price</button>
          <button onClick={() => deletePlant(plant.id)}>Delete</button>
        </div>
      )}
    </li>
  );
}