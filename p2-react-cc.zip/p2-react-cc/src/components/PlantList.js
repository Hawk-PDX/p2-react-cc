import PlantCard from "./PlantCard";

export default function PlantList({ plants, markSoldOut, updatePlantPrice, deletePlant }) {
  return (
    <ul className="cards">
      {plants.map((plant) => (
        <PlantCard
          key={plant.id}
          plant={plant}
          markSoldOut={markSoldOut}
          updatePlantPrice={updatePlantPrice}
          deletePlant={deletePlant}
        />
      ))}
    </ul>
  );
}